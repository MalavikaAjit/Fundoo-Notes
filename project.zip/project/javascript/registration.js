

/********password-toggle**/
$(document).on('change', '.password-toggle', function(e) {
// const passwordToggle = document.querySelector('.password-toggle')

// passwordToggle.addEventListener('change', function() {
  const password = document.querySelector('.showPassword')
  
  if (password.type === 'password') {
    password.type = 'text'
  } else {
    password.type = 'password'
  }
  
  
})



/***toggle sidebar**/

$( document ).ready(function() {
    let sidebar = document.querySelector(".sidebar");
    let closeBtn = document.querySelector("#btn");
    
    closeBtn.addEventListener("click", ()=>{
      sidebar.classList.toggle("open");
    });
} );


/****toggle text field***/


function openNotes(){
  // $('#form').addClass('form-open');
      document.querySelector("#note-title").style.display = "block";
      document.querySelector("#form-buttons").style.display = "block";
}

function closeNotes(){
  document.querySelector("#note-title").style.display = "none";
  document.querySelector("#form-buttons").style.display = "none";
  document.getElementById('note-text').value='';
  document.getElementById('note-title').value='';
}


const placeholder = document.querySelector("#placeholder");
const notesField = document.querySelector("#notes");

function displayNotes() {
  const notes = JSON.parse(localStorage.getItem('notes')) || []; 
  const hasNotes = notes.length > 0;
  placeholder.style.display = hasNotes ? 'none' : 'flex';
   notesField.innerHTML = notes.map(note => `
      <div class="note">
        <div class="note-title">${note.title}</div>
        <div class="note-text">${note.description}</div>
        <div class="toolbar-container">
          <div class="toolbar">         
          <i class="fas fa-trash" id="${note.id}" onclick="deleteNote(id)"></i>  
         
          <i class="material-icons">more_vert</i> 
          <i class="material-icons">archive</i>
          <i class="material-icons">palette</i> 
          <i class="material-icons">person_add_alt</i> 
          <i class="material-icons">add_alert</i>       
          </div>
        </div>
      </div>
   `).join("");
}
displayNotes();



/*****modal for collaborators***/

$('#myModal').on('shown.bs.modal', function () {
  $('#myInput').trigger('focus')
})

/******/

function addCollabIcon(){
 const mail= document.getElementById('#searchValue');
 console.log(mail);
}









